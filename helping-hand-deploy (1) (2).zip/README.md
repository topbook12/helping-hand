# 🎓 Helping Hand - ICE Department

A comprehensive Ebook, Class Note, and Notice Management System for ICE Department.

![Next.js](https://img.shields.io/badge/Next.js-16-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-cyan)
![Prisma](https://img.shields.io/badge/Prisma-PostgreSQL-green)

## ✨ Features

### 👨‍🎓 Student Features
- 📚 Browse and download ebooks
- 📝 Access class notes by subject/semester
- 📰 View important notices
- 💝 Like and share content
- 🛒 Student deals with affiliate links

### 👨‍🏫 Teacher Dashboard
- 📤 Upload books and notes
- 📝 Create notices
- 📊 Track uploads statistics

### 👑 Admin Dashboard
- 👥 Manage users (teachers)
- 📋 Full content management
- ⚙️ Site settings
- 🔗 Social links management

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ or Bun
- PostgreSQL database (Supabase/Neon)
- Cloudinary account (for file uploads)

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/helping-hand.git
cd helping-hand

# Install dependencies
bun install

# Copy environment variables
cp .env.example .env

# Setup database
bun run db:push

# Run development server
bun run dev
```

Open [http://localhost:3000](http://localhost:3000)

### Default Admin Login
- **Email:** admin@ice.edu
- **Password:** admin123

⚠️ **Change the password after first login!**

## 📦 Deployment

### Deploy to Vercel (Recommended)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/helping-hand)

1. Fork this repository
2. Create a new project on Vercel
3. Add environment variables
4. Deploy!

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | ✅ |
| `DIRECT_DATABASE_URL` | Direct database URL | ✅ |
| `CLOUDINARY_CLOUD_NAME` | Cloudinary cloud name | ✅ |
| `CLOUDINARY_API_KEY` | Cloudinary API key | ✅ |
| `CLOUDINARY_API_SECRET` | Cloudinary API secret | ✅ |

## 🛠️ Tech Stack

- **Frontend:** Next.js 16, React 19, TypeScript
- **Styling:** Tailwind CSS 4, shadcn/ui
- **Database:** PostgreSQL (Prisma ORM)
- **Animations:** Framer Motion
- **File Storage:** Cloudinary
- **Deployment:** Vercel

## 📁 Project Structure

```
helping-hand/
├── prisma/
│   └── schema.prisma      # Database schema
├── src/
│   ├── app/
│   │   ├── api/           # API routes
│   │   ├── page.tsx       # Main page
│   │   └── layout.tsx     # Root layout
│   ├── components/
│   │   └── ui/            # shadcn/ui components
│   ├── lib/
│   │   └── db.ts          # Database client
│   └── store/
│       └── auth-store.ts  # Auth state
├── .env.example
├── package.json
└── README.md
```

## 🔒 Security

- Password hashing (Base64 - upgrade to bcrypt for production)
- Cookie-based authentication
- Protected API routes
- Input validation

## 📄 License

MIT License - feel free to use for educational purposes!

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

Made with ❤️ for ICE Department

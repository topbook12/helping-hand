# 🚀 সহজ ডিপ্লয়মেন্ট গাইড

## আপনার যা লাগবে:
1. ✅ GitHub অ্যাকাউন্ট (ফ্রি)
2. ✅ Supabase অ্যাকাউন্ট (ফ্রি)
3. ✅ Vercel অ্যাকাউন্ট (ফ্রি)

---

## ধাপ ১: GitHub-এ কোড আপলোড (২ মিনিট)

### ১.১ নতুন Repository তৈরি করুন:
1. https://github.com/new এ যান
2. Repository name: `helping-hand`
3. ✅ Public সিলেক্ট করুন
4. "Create repository" ক্লিক করুন

### ১.২ কোড আপলোড করুন:
এই প্রজেক্টের সব ফাইল ডাউনলোড করুন এবং GitHub-এ আপলোড করুন।

---

## ধাপ ২: Supabase ডেটাবেজ (৫ মিনিট)

### ২.১ অ্যাকাউন্ট তৈরি:
1. https://supabase.com এ যান
2. "Start your project" → GitHub দিয়ে সাইন আপ

### ২.২ প্রজেক্ট তৈরি:
1. "New Project" ক্লিক
2. Name: `helping-hand`
3. Password: **মনে রাখবেন এই পাসওয়ার্ড!**
4. Region: Singapore
5. "Create new project"

### ২.৩ কানেকশন স্ট্রিং পান:
1. প্রজেক্ট খুলুন
2. **Settings** (বাম সাইডবার) এ ক্লিক
3. **Database** এ ক্লিক
4. নিচে স্ক্রল করুন → **Connection string** সেকশন
5. **URI** ট্যাব সিলেক্ট করুন
6. **Connection pooling** → **Transaction** সিলেক্ট করুন
7. **Copy** ক্লিক করুন

```
উদাহরণ:
postgresql://postgres.abc123xyz:YOUR_PASSWORD@aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres
```

### ২.৪ Direct URL পান:
একই জায়গায় **Session** মোড সিলেক্ট করে আরেকটি URL কপি করুন:
```
postgresql://postgres.abc123xyz:YOUR_PASSWORD@aws-0-ap-southeast-1.pooler.supabase.com:5432/postgres
```

---

## ধাপ ৩: Vercel ডিপ্লয় (৫ মিনিট)

### ৩.১ Vercel সেটআপ:
1. https://vercel.com এ যান
2. "Sign Up" → GitHub দিয়ে সাইন আপ

### ৩.২ প্রজেক্ট ইমপোর্ট:
1. "Add New" → "Project"
2. GitHub repository সিলেক্ট করুন (`helping-hand`)
3. "Import" ক্লিক

### ৩.৩ Environment Variables:
"Environment Variables" সেকশনে এই ২টি যোগ করুন:

| Name | Value |
|------|-------|
| `DATABASE_URL` | Supabase Transaction URL |
| `DIRECT_DATABASE_URL` | Supabase Session URL |

### ৩.৪ Deploy:
1. "Deploy" ক্লিক করুন
2. ২-৩ মিনিট অপেক্ষা করুন
3. 🎉 আপনার সাইট রেডি!

---

## ✅ সফল ডিপ্লয়মেন্ট!

আপনার সাইট URL পাবেন:
```
https://helping-hand-xxx.vercel.app
```

### Admin Login:
- Email: `admin@ice.edu`
- Password: `admin123`

⚠️ **প্রথম লগইনের পর পাসওয়ার্ড পরিবর্তন করুন!**

---

## সমস্যা হলে?

### Database Error:
- DATABASE_URL সঠিক কিনা চেক করুন
- Password ঠিক আছে কিনা দেখুন

### Build Error:
- GitHub-এ সব ফাইল আপলোড হয়েছে কিনা চেক করুন

---

**মোট খরচ: $0/মাস** 💰

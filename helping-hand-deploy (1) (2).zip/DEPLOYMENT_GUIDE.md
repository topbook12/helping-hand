# 🚀 Helping Hand - প্রোডাকশন ডিপ্লয়মেন্ট গাইড

## 📋 সংক্ষিপ্ত বিবরণ

এই গাইডটি আপনাকে "Helping Hand" অ্যাপ্লিকেশনটি বিনামূল্যে রিয়েল ওয়ার্ল্ডে ডিপ্লয় করতে সাহায্য করবে।

---

## 🎯 স্টেপ ১: Supabase-এ ডেটাবেজ তৈরি (বিনামূল্যে)

### ১.১ Supabase অ্যাকাউন্ট খুলুন
1. https://supabase.com এ যান
2. "Start your project" ক্লিক করুন
3. GitHub দিয়ে সাইন আপ করুন (সহজ)

### ১.২ নতুন প্রজেক্ট তৈরি করুন
1. "New Project" ক্লিক করুন
2. Organization: নতুন বা এক্সিস্টিং
3. Project name: `helping-hand`
4. Database password: **শক্তিশালী পাসওয়ার্ড দিন এবং সংরক্ষণ করুন!**
5. Region: `Southeast Asia (Singapore)` বা কাছাকাছি রিজিওন
6. "Create new project" ক্লিক করুন

### ১.৩ ডেটাবেজ কানেকশন স্ট্রিং পান
1. Project Dashboard এ যান
2. Settings → Database এ ক্লিক করুন
3. "Connection string" সেকশনে যান
4. "URI" কপি করুন (Transaction pooler ব্যবহার করুন)

```
postgresql://postgres.[project-ref]:[password]@aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres
```

---

## 🎯 স্টেপ ২: ফাইল আপলোডের জন্য Cloudinary সেটআপ

### ২.১ Cloudinary অ্যাকাউন্ট
1. https://cloudinary.com এ যান
2. ফ্রি অ্যাকাউন্ট তৈরি করুন
3. Dashboard থেকে এই তিনটি কপি করুন:
   - Cloud Name
   - API Key
   - API Secret

---

## 🎯 স্টেপ ৩: Vercel-এ ডিপ্লয় (বিনামূল্যে)

### ৩.১ GitHub-এ কোড আপলোড
```bash
# আপনার কম্পিউটারে
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/helping-hand.git
git push -u origin main
```

### ৩.২ Vercel-এ ডিপ্লয়
1. https://vercel.com এ যান
2. GitHub দিয়ে সাইন আপ/লগইন
3. "New Project" ক্লিক করুন
4. GitHub repository সিলেক্ট করুন
5. Environment Variables যোগ করুন:

```
DATABASE_URL=postgresql://postgres.[ref]:[password]@...
DIRECT_DATABASE_URL=postgresql://postgres.[ref]:[password]@...
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

6. "Deploy" ক্লিক করুন

---

## 🎯 স্টেপ ৪: প্রোডাকশনের জন্য প্রস্তুতি

### ৪.১ Prisma Migrate চালান
Vercel ডিপ্লয়ের সময় স্বয়ংক্রিয়ভাবে হবে, তবে লোকালি টেস্ট করতে:

```bash
# PostgreSQL schema ব্যবহার করুন
cp prisma/schema.postgres.prisma prisma/schema.prisma

# Migrate চালান
bunx prisma migrate dev --name init
```

### ৪.২ Environment Variables (.env)
```env
# Database
DATABASE_URL="your_supabase_connection_string"
DIRECT_DATABASE_URL="your_supabase_direct_connection"

# Cloudinary (File Upload)
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME="your_cloud_name"
CLOUDINARY_API_KEY="your_api_key"
CLOUDINARY_API_SECRET="your_api_secret"

# App URL
NEXT_PUBLIC_APP_URL="https://your-app.vercel.app"
```

---

## 🔐 সিকিউরিটি চেকলিস্ট

### ✅ করণীয়:
- [ ] শক্তিশালী Admin পাসওয়ার্ড পরিবর্তন করুন
- [ ] `.env` ফাইল GitHub-এ আপলোড করবেন না
- [ ] Database password নিরাপদ স্থানে সংরক্ষণ করুন
- [ ] HTTPS ব্যবহার করুন (Vercel স্বয়ংক্রিয়ভাবে দেয়)

### ❌ করণীয় নয়:
- [ ] Default password ব্যবহার করবেন না
- [ ] API keys পাবলিকলি শেয়ার করবেন না
- [ ] Unvalidated user input গ্রহণ করবেন না

---

## 💰 খরচের হিসাব (সব ফ্রি!)

| সার্ভিস | ফ্রি লিমিট | মাসিক খরচ |
|---------|------------|----------|
| Vercel | 100GB bandwidth | $0 |
| Supabase | 500MB database | $0 |
| Cloudinary | 25GB storage | $0 |

**মোট: $0/মাস** 🎉

---

## 📱 কাস্টম ডোমেইন (ঐচ্ছিক)

আপনার নিজস্ব ডোমেইন যোগ করতে:

1. Vercel Dashboard → Settings → Domains
2. আপনার ডোমেইন যোগ করুন (যেমন: `helpinghand.yoursite.com`)
3. DNS records আপডেট করুন

---

## 🆘 সমস্যা সমাধান

### Database Connection Error
```
Error: P1001: Can't reach database server
```
**সমাধান:** DATABASE_URL সঠিকভাবে কপি করেছেন কিনা চেক করুন

### Build Failed
```
Error: Build failed
```
**সমাধান:** 
1. `bun install` চালান
2. `bun run build` লোকালি টেস্ট করুন

### File Upload Not Working
**সমাধান:** Cloudinary credentials সঠিকভাবে সেট করুন

---

## 📞 সাপোর্ট

কোনো সমস্যা হলে:
1. Vercel Logs চেক করুন
2. Supabase Dashboard এ Logs দেখুন
3. আমাকে জিজ্ঞাসা করুন!

---

**সাফল্যের শুভকামনা! 🎉**
